#include <stdio.h>

int main()
{
    char yolo[0x400];
    fgets(yolo, 0x539, stdin);
}
