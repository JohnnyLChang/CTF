SetOptions[$FrontEndSession,
PrivatePaths -> {"SystemResources" -> {ParentList}, 
  "TextResources" -> {FrontEnd`FileName[{"/opt/Wolfram/WolframEngine/10.0/Add\
Ons/Applications/WolframAlphaClient/FrontEnd", "TextResources"}, 
     "PacletManager" -> True, "Prepend" -> True], ParentList}}
]