SetOptions[$FrontEnd, 
Current2DTool->"Select",
Default2DTool->"Select",
Current3DTool->"RotateView",
Default3DTool->"RotateView"
]
