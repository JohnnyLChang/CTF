#!/bin/bash
echo "AirPlay server is running..."
shairport/./shairport.pl -a RoPlay
