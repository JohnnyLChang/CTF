#include <gmp.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define BITS 1024
#define N "d1e44ef6c387eeff8b4852372a68cfdcfe3c14da22f1933e3d0fb11d434f480e3415ab08ee42e8d5a7a5ad34e1c114e5d7f2fa970eb968d492542089325301f4090c850c4ece500388d720fb7b5e2772a063ecf238675b8bcde0cb8ba54eb663d74b80e459c803980d7f5cbe4fc76aa036dfc3d6e7a7ec750f2a4ef2658c9029"
#define e 3

char flag[BITS / 8];
char message[BITS];
void read_flag() {
  int i = 0;
  FILE *fp = fopen("flag", "rb");
  fgets(flag, 32, fp);
  for(i = strlen(flag); i < sizeof(flag); i++) {
    flag[i] = rand() % 256;
  }
}

int main() {
  int i, j;
  mpz_t m, n, c;
  mpz_init(m);
  mpz_init(n);
  mpz_init(c);

  read_flag();
  for(i = 0; i < sizeof(flag); i++) {
    sprintf(&message[i * 2], "%02x", (unsigned int)flag[i]);
  }
  mpz_set_str(n, N, 16);
  mpz_set_str(m, message, 16);
  mpz_powm_ui(c, m, e, n);
  printf("Encrypted flag: ");
  mpz_out_str(stdout, 16, c);
  puts("");
}
